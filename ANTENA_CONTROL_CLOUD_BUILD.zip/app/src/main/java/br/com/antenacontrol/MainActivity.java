package br.com.antenacontrol;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.telephony.CellSignalStrength;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_PHONE = 41;
    private TelephonyManager telephony;
    private PhoneStateListener listener;
    private TextView dbmValue, qualityValue, networkValue, statusValue, txValue;
    private boolean listening = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
        telephony = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, REQ_PHONE);
        } else {
            startMonitoring();
        }
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        c.setBackgroundColor(Color.rgb(20, 29, 43));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, dp(12));
        parent.addView(c, p);
        return c;
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(18));
        root.setBackgroundColor(Color.rgb(8, 13, 22));

        TextView brand = text("ANTENA CONTROL", 23, Color.WHITE, true);
        root.addView(brand);
        TextView subtitle = text("PAINEL DE DIAGNÓSTICO DE REDE", 11, Color.rgb(53,182,255), true);
        subtitle.setPadding(0, dp(4), 0, dp(20));
        root.addView(subtitle);

        LinearLayout signal = card(root);
        signal.addView(text("INTENSIDADE DO SINAL", 12, Color.LTGRAY, true));
        dbmValue = text("-- dBm", 42, Color.rgb(53,182,255), true);
        dbmValue.setPadding(0, dp(8), 0, 0);
        signal.addView(dbmValue);
        qualityValue = text("Aguardando leitura do modem…", 13, Color.LTGRAY, false);
        signal.addView(qualityValue);

        LinearLayout network = card(root);
        network.addView(text("REDE MÓVEL", 12, Color.LTGRAY, true));
        networkValue = text("Identificando…", 22, Color.WHITE, true);
        networkValue.setPadding(0, dp(8), 0, 0);
        network.addView(networkValue);
        statusValue = text("Monitoramento aguardando permissão", 13, Color.LTGRAY, false);
        network.addView(statusValue);

        LinearLayout power = card(root);
        power.addView(text("POTÊNCIA DE TRANSMISSÃO", 12, Color.LTGRAY, true));
        txValue = text("Não disponibilizada pelo Android", 17, Color.rgb(255,190,90), true);
        txValue.setPadding(0, dp(8), 0, dp(5));
        power.addView(txValue);
        power.addView(text("O modem/firmware do aparelho precisa expor um controle autorizado. Este aplicativo não simula alterações.", 12, Color.LTGRAY, false));

        Button settings = new Button(this);
        settings.setText("ABRIR CONFIGURAÇÕES DE REDE");
        settings.setTextColor(Color.WHITE);
        settings.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(20, 105, 160)));
        root.addView(settings, new LinearLayout.LayoutParams(-1, dp(54)));
        settings.setOnClickListener(v -> {
            try { startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS)); }
            catch (Exception e) { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); }
        });

        TextView note = text("V1.0 • Leitura informativa. Não altera a potência RF da antena.", 10, Color.GRAY, false);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(16), 0, 0);
        root.addView(note);

        setContentView(root);
    }

    private void startMonitoring() {
        if (listening || telephony == null) return;
        try {
            networkValue.setText(networkName(telephony.getDataNetworkType()));
            listener = new PhoneStateListener() {
                @Override public void onSignalStrengthsChanged(SignalStrength signalStrength) {
                    super.onSignalStrengthsChanged(signalStrength);
                    updateSignal(signalStrength);
                }
            };
            telephony.listen(listener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
            listening = true;
            statusValue.setText("Monitoramento ativo • aguardando atualização");
        } catch (SecurityException e) {
            statusValue.setText("Permissão de telefone não concedida");
        } catch (Exception e) {
            statusValue.setText("Não foi possível iniciar a leitura neste aparelho");
        }
    }

    private void updateSignal(SignalStrength s) {
        int best = Integer.MAX_VALUE;
        try {
            List<CellSignalStrength> cells = s.getCellSignalStrengths();
            for (CellSignalStrength cell : cells) {
                int value = cell.getDbm();
                if (value < 0 && value > -200 && value < best) best = value;
            }
        } catch (Exception ignored) { }
        if (best == Integer.MAX_VALUE) {
            dbmValue.setText("Indisponível");
            qualityValue.setText("O modem não forneceu um valor em dBm");
        } else {
            final int dbm = best;
            dbmValue.setText(String.format(Locale.getDefault(), "%d dBm", dbm));
            String quality;
            if (dbm >= -85) quality = "Excelente";
            else if (dbm >= -100) quality = "Bom";
            else if (dbm >= -110) quality = "Fraco";
            else quality = "Muito fraco";
            qualityValue.setText("Qualidade estimada: " + quality);
        }
        try { networkValue.setText(networkName(telephony.getDataNetworkType())); }
        catch (Exception ignored) { }
        statusValue.setText("Última leitura recebida do modem");
    }

    private String networkName(int type) {
        switch (type) {
            case TelephonyManager.NETWORK_TYPE_LTE: return "4G / LTE";
            case TelephonyManager.NETWORK_TYPE_NR: return "5G / NR";
            case TelephonyManager.NETWORK_TYPE_HSPA:
            case TelephonyManager.NETWORK_TYPE_HSPAP:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
            case TelephonyManager.NETWORK_TYPE_HSDPA: return "3G / HSPA";
            case TelephonyManager.NETWORK_TYPE_UMTS: return "3G / UMTS";
            case TelephonyManager.NETWORK_TYPE_EDGE: return "2G / EDGE";
            case TelephonyManager.NETWORK_TYPE_GPRS: return "2G / GPRS";
            default: return "Tipo de rede não identificado";
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_PHONE) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startMonitoring();
            else statusValue.setText("Permissão negada • leitura de sinal desativada");
        }
    }

    @Override protected void onDestroy() {
        if (telephony != null && listener != null) {
            try { telephony.listen(listener, PhoneStateListener.LISTEN_NONE); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }
}
