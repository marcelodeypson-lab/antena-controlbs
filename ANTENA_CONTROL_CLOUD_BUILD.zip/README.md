# ANTENA CONTROL 1.0 — compilação na nuvem pelo celular

Este pacote contém o projeto Android e um fluxo do GitHub Actions para compilar o APK sem Android Studio e sem computador.

## O que o app faz nesta primeira versão
- Solicita permissão de telefone.
- Exibe intensidade do sinal em dBm quando o modem/Android fornece a leitura.
- Identifica a tecnologia de rede de dados disponível.
- Abre as configurações de rede do Android.

**Limitação importante:** a versão 1.0 não altera a potência de transmissão RF. Android e modem normalmente não expõem esse controle a aplicativos comuns. Não há controle deslizante falso.

## Como gerar o APK usando apenas o Moto G60s

1. No navegador do celular, entre em https://github.com/ e crie uma conta ou faça login.
2. Toque no `+` e escolha **New repository**.
3. Nome do repositório: `antena-control`. Marque **Public** (ou Private, se preferir) e crie.
4. Abra o repositório e escolha **Add file → Upload files**.
5. Extraia este ZIP no celular usando o gerenciador de arquivos. Ative a opção para mostrar arquivos ocultos, se houver, para localizar a pasta `.github`.
6. Envie o conteúdo da pasta do projeto para a raiz do repositório, incluindo a pasta oculta `.github/workflows`. Não envie a pasta externa `ANTENA_CONTROL_CLOUD` como uma subpasta; envie os arquivos e pastas que estão dentro dela.
7. Faça **Commit changes** na branch `main`.
8. No repositório, abra a aba **Actions**. Se aparecer uma confirmação para habilitar workflows, confirme.
9. Abra **Build ANTENA CONTROL APK** e aguarde a execução terminar com marca verde.
10. Abra a execução concluída, desça até **Artifacts** e toque em `ANTENA-CONTROL-1.0-debug` para baixar o ZIP do APK.
11. Extraia o ZIP baixado. Toque em `app-debug.apk` e, se o Android solicitar, permita a instalação desse app de origem desconhecida nas configurações.

## Observações
- O APK gerado é de depuração (debug), adequado para teste e instalação manual.
- O GitHub pode solicitar verificação de conta ou apresentar telas diferentes conforme a versão do site.
- O artefato fica disponível por 14 dias; baixe e guarde o APK.
- Se a compilação falhar, envie uma captura da tela do erro para que possamos corrigir o projeto.
